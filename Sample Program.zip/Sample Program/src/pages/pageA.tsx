import * as React from "react";
import { Link } from "react-router-dom";
import { downloadDocument } from "./download";

export const PageA: React.FC = () => {

  function btnClick(): void {
    downloadDocument();
  }

  return (
    <div>
      <h2>Home Page</h2>
      <br />
      <button onClick={btnClick} title="Download Document">Download Document</button>
      <br />
      <br />
      <Link to="/documents/file">Navigate to File Page</Link>
    </div>
  )
}

export default PageA;
