export const BlobHandler = {
  arrayBufferToBlob(arrayBuffer: any): Blob {
    const arr = new Uint8Array(arrayBuffer);
    return new Blob([arr], { type: "application/pdf" });
  },
  downloadBlob(blob: Blob, documentTitle: string): void {
    const blobURL = window.URL.createObjectURL(blob);
    const tempLink = document.createElement("a");
    tempLink.href = blobURL;
    tempLink.setAttribute("download", documentTitle + ".pdf");
    tempLink.click();
  }
};

export const downloadProcessedData = (documentTitle: string, data: any): void => {
  const blob = BlobHandler.arrayBufferToBlob(data);
  BlobHandler.downloadBlob(blob, documentTitle);
};

export function downloadDocument(): void {
  const options = {
    extension: "pdf"
  };
  const pdftronCreateDocument = (window as any).CoreControls.createDocument("https://pdftron.s3.amazonaws.com/downloads/pl/webviewer-demo.pdf", options);
  pdftronCreateDocument.then(function (pdftronCreatedDocumentPromise: any) {
    pdftronCreatedDocumentPromise.getFileData().then((data: any) => {
      downloadProcessedData("Test Document", data);
    }).catch((error: any) => {
      console.log(error);
    });
  }).catch((error: any) => {
    console.log(error);
  });
}