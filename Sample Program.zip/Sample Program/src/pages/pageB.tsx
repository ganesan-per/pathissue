import * as React from "react";
import { Link } from "react-router-dom";
import { downloadDocument } from "./download";

export const PageB: React.FC = () => {

  function btnClick(): void {
    downloadDocument();
  }

  return (
    <div>
      <h2>File Page</h2>
      <br />
      <button onClick={btnClick} title="Download Document">Download Document</button>
      <br/>
      <br/>
      <Link to="/">Navigate to Home</Link>
    </div>
  )
}

export default PageB;
