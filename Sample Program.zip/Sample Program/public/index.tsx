import * as React from "react";
import * as ReactDOM from "react-dom";
import { Route, BrowserRouter as Router, Switch } from 'react-router-dom'
import PageB from "../src/pages/pageB";
import PageA from "../src/pages/pageA";

const routing = (
  <Router>
    <div className="page">
      <Switch>
        <Route exact={true} path="/" component={PageA} />
        <Route path="/documents/file" component={PageB} />
      </Switch>
    </div>
  </Router>
)


ReactDOM.render(routing, document.getElementById("root"));
